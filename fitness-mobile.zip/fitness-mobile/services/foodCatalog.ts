// services/foodCatalog.ts
import {
  collection,
  doc,
  getFirestore,
  query,
  where,
  orderBy,
  limit,
  getDocs,
  setDoc,
  increment,
  serverTimestamp,
  updateDoc,
} from "firebase/firestore";
import { app } from "@/lib/firebase";

const db = getFirestore(app);

export type FoodCatalogItem = {
  name: string;
  unit: string;
  qty: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  sugar?: number;
  fiber?: number;
  nameLower: string;
  tokens: string[];
  createdAt: number;
  updatedAt: number;
  submitterUid?: string;
  uses?: number;
  verified?: boolean;
};

function slugify(s: string) {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9 ]+/g, "")
    .replace(/\s+/g, " ")
    .trim();
}
export function foodIdFor(name: string, unit: string) {
  return `${slugify(name)}|${slugify(unit)}`;
}
function tokenize(name: string) {
  return slugify(name).split(" ").filter(Boolean);
}

export async function upsertFoodToCatalog(
  item: Omit<
    FoodCatalogItem,
    "nameLower" | "tokens" | "createdAt" | "updatedAt" | "uses"
  > & { submitterUid?: string }
) {
  const id = foodIdFor(item.name, item.unit);
  const now = Date.now();
  const ref = doc(db, "foodCatalog", id);
  await setDoc(
    ref,
    {
      ...item,
      nameLower: item.name.toLowerCase(),
      tokens: tokenize(item.name),
      createdAt: now,
      updatedAt: now,
      uses: increment(1), // counts how often it’s been used
    },
    { merge: true }
  );
  return ref;
}

export async function searchCatalog(qstr: string, max = 25) {
  const qnorm = slugify(qstr);
  if (!qnorm) return [];
  const words = qnorm.split(" ").filter(Boolean);
  // simple array-contains-any by tokens; AND semantics require multiple queries,
  // we keep OR for speed/cheapness.
  const col = collection(db, "foodCatalog");
  const q = query(
    col,
    where("tokens", "array-contains-any", words.slice(0, 10)),
    orderBy("uses", "desc"),
    limit(max)
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({
    id: d.id,
    ...(d.data() as any),
  })) as (FoodCatalogItem & { id: string })[];
}

// optional: record a use if you select a catalog item without editing
export async function bumpUse(foodId: string) {
  const ref = doc(db, "foodCatalog", foodId);
  await updateDoc(ref, { uses: increment(1), updatedAt: Date.now() });
}
