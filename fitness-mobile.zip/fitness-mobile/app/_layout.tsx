// app/_layout.tsx
import "react-native-reanimated";

import React, { useEffect, useRef } from "react";
import {
  ActivityIndicator,
  View,
  Text,
  StyleSheet,
  Platform,
} from "react-native";
import { Stack, usePathname, useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import {
  SafeAreaProvider,
  useSafeAreaInsets,
} from "react-native-safe-area-context";

import { AuthProvider, useAuth } from "@/content/AuthContext";
import { ThemeProvider, useTheme } from "@/content/ThemeProvider";
import { SettingsProvider } from "@/content/SettingsContext";

import { auth, db } from "@/lib/firebase";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import AsyncStorage from "@react-native-async-storage/async-storage";

/* ---------- Tiny glossy header that's always present ---------- */
function GlobalTopHeader() {
  const { isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const height = insets.top + 10; // safe-area + small buffer

  let BlurView: any = View;
  try {
    BlurView = require("expo-blur").BlurView;
  } catch {
    // if expo-blur is missing, we still render the spacer
  }

  return (
    <View
      pointerEvents="none"
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        height,
        zIndex: 1000,
        overflow: "hidden",
      }}
    >
      <View
        style={[
          StyleSheet.absoluteFill,
          {
            backgroundColor: isDark
              ? "rgba(12,14,20,0.62)"
              : "rgba(245,248,255,0.58)",
          },
        ]}
      />
      {BlurView !== View && (
        <BlurView
          intensity={22}
          tint={isDark ? "dark" : "light"}
          style={StyleSheet.absoluteFill}
        />
      )}
      {/* subtle bottom fade */}
      <View
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          bottom: 0,
          height: 10,
          backgroundColor: isDark
            ? "rgba(0,0,0,0.18)"
            : "rgba(255,255,255,0.18)",
        }}
      />
    </View>
  );
}

function Gate() {
  const { user, initializing } = useAuth();
  const pathname = usePathname();
  const router = useRouter();
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const enforcedRef = useRef(false);

  const inAuth =
    pathname?.startsWith("/(auth)") ||
    pathname === "/login" ||
    pathname === "/register" ||
    pathname === "/reset";

  // remember-me logic
  useEffect(() => {
    if (initializing || enforcedRef.current) return;
    (async () => {
      const remember = (await AsyncStorage.getItem("@rememberMe")) === "1";
      if (!user) {
        if (!inAuth) router.replace("/(auth)/login");
        enforcedRef.current = true;
        return;
      }
      if (!remember) {
        try {
          await signOut(auth);
        } finally {
          router.replace("/(auth)/login");
          enforcedRef.current = true;
        }
      } else {
        if (inAuth) router.replace("/(tabs)");
        enforcedRef.current = true;
      }
    })();
  }, [user, initializing, inAuth]);

  // ensure user doc
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      if (!u) return;
      const ref = doc(db, "users", u.uid);
      const snap = await getDoc(ref);
      if (!snap.exists()) {
        await setDoc(ref, {
          email: u.email ?? null,
          displayName: u.displayName ?? null,
          photoURL: u.photoURL ?? null,
          createdAt: serverTimestamp(),
        });
      }
    });
    return unsub;
  }, []);

  if (initializing) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: colors.background,
        }}
      >
        <StatusBar style={isDark ? "light" : "dark"} />
        <ActivityIndicator color={colors.primary} />
        <Text style={{ marginTop: 8, color: colors.muted }}>Loading…</Text>
      </View>
    );
  }

  const topHeaderHeight = insets.top + 10;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {/* Translucent so our header shows behind the system area */}
      <StatusBar
        style={isDark ? "light" : "dark"}
        translucent
        backgroundColor="transparent"
      />

      {/* Always-present glossy header spacer */}
      {/* <GlobalTopHeader /> */}

      <Stack
        screenOptions={{
          headerShown: false, // we’re using the global top header now
          contentStyle: {
            backgroundColor: colors.background,
            // Push *every* screen content down so it starts below the global header
            paddingTop: topHeaderHeight,
          },
        }}
      >
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="(auth)" />
        <Stack.Screen
          name="(modals)"
          options={{
            presentation: "fullScreenModal",
            contentStyle: {
              backgroundColor: colors.background,
              paddingTop: topHeaderHeight,
            },
            headerShown: false,
          }}
        />
        <Stack.Screen name="+not-found" />
      </Stack>
    </View>
  );
}

export default function RootLayout() {
  return (
    <SettingsProvider>
      <ThemeProvider>
        <SafeAreaProvider>
          <View style={{ flex: 1 }}>
            <AuthProvider>
              <Gate />
            </AuthProvider>
          </View>
        </SafeAreaProvider>
      </ThemeProvider>
    </SettingsProvider>
  );
}
